const formatArgs = function(args) {
  const userArgs = args.slice(2);
  return userArgs;
};

const add = function(value1, value2) {
  return (+value1) + (+value2);
};

const getOperation = function(operatorName) {
  const operatorTable = {
    sum: add,
  };
  const operation = operatorTable[operatorName];
  return operation
};

const operationOverRange = function(operation, begin, end) {
  if(operation == undefined){
    return 0;
  }

  let result = 0;
  for(let count=begin; count<=end; count++){
    result = operation(count, result);
  } 

  return result;
};

const evaluate = function(args) {
  const userArgs = formatArgs(args);
  const operatorName = userArgs[0];
  const operation = getOperation(operatorName);
  const value1 = userArgs[1];
  const value2 = userArgs[2];
  const result = operationOverRange(operation, value1, value2);
  return result;
};

exports.formatArgs = formatArgs;
exports.add = add
exports.getOperation = getOperation;
exports.operationOverRange = operationOverRange
exports.evaluate = evaluate;
